from django.apps import AppConfig

class HouseholdsConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "apps.households"
    verbose_name = "Households"
